import numpy as np


def conv_nested(image, kernel):
    """A naive implementation of convolution filter.

    This is a naive implementation of convolution using 4 nested for-loops.
    This function computes convolution of an image with a kernel and outputs
    the result that has the same shape as the input image.

    Args:
        image: numpy array of shape (Hi, Wi).
        kernel: numpy array of shape (Hk, Wk).

    Returns:
        out: numpy array of shape (Hi, Wi).
    """
     
    Hi, Wi = image.shape
    Hk, Wk = kernel.shape
    out = np.zeros((Hi, Wi))
    HiCen=(Hk//2)
    WiCen=(Wk//2)
    out2=np.zeros((Hi+Hk-1,Wi+Wk-1))
    ### YOUR CODE HERE
    for m in range(0,Hi+Hk-1):
        for n in range(0,Wi+Wk-1):
            for i in range(-HiCen,Hk-HiCen):
                for j in range(-WiCen,Wk-WiCen):
                    if m-i<0 or n-j<0 or m-i>=Hi or n-j>=Wi:
                        out2[m,n]+=0
                    else:
                        out2[m,n]+=kernel[i+HiCen,j+WiCen]*image[m-i,n-j]
                
    ### END YOUR CODE
    out=out2[0:Hi,0:Wi]
    return out



def zero_pad(image, pad_height, pad_width):
    """ Zero-pad an image.

    Ex: a 1x1 image [[1]] with pad_height = 1, pad_width = 2 becomes:

        [[0, 0, 0, 0, 0],
         [0, 0, 1, 0, 0],
         [0, 0, 0, 0, 0]]         of shape (3, 5)

    Args:
        image: numpy array of shape (H, W).
        pad_width: width of the zero padding (left and right padding).
        pad_height: height of the zero padding (bottom and top padding).

    Returns:
        out: numpy array of shape (H+2*pad_height, W+2*pad_width).
    """

    sp=np.shape(image)
    H= sp[0]
    W= sp[1]
   
    ### YOUR CODE HERE
    newh=H+2*pad_height
    neww=W+2*pad_width
    out=np.zeros((newh,neww))
    out[pad_height:(newh-pad_height),pad_width:(neww-pad_width)]=image
    ### END YOUR CODE
    
    return out


def conv_fast(image, kernel):
    """ An efficient implementation of convolution filter.

    This function uses element-wise multiplication and np.sum()
    to efficiently compute weighted sum of neighborhood at each
    pixel.

    Hints:
        - Use the zero_pad function you implemented above
        - There should be two nested for-loops
        - You may find np.flip() and np.sum() useful

    Args:
        image: numpy array of shape (Hi, Wi).
        kernel: numpy array of shape (Hk, Wk).

    Returns:
        out: numpy array of shape (Hi, Wi).
    """
    Hi,Wi=image.shape
    kernel = np.flip(kernel)
    output = np.zeros_like(image)         
    
    print(kernel)
    image_padded=zero_pad(image,1,1)
    for i in range(Hi):     
        for j in range(Wi):
            output[i,j]=(kernel*image_padded[i:i+3,j:j+3]).sum()        
    return output



def cross_correlation(f, g):
    """ Cross-correlation of f and g.

    Hint: use the conv_fast function defined above.

    Args:
        f: numpy array of shape (Hf, Wf).
        g: numpy array of shape (Hg, Wg).

    Returns:
        out: numpy array of shape (Hf, Wf).
    """

    Hi,Wi=f.shape
    out=feature.match_template(f,g) #using builtin skimage function for correlation
    return out[0:Hi,0:Wi]

def zero_mean_cross_correlation(f, g):
    """ Zero-mean cross-correlation of f and g.

    Subtract the mean of g from g so that its mean becomes zero.

    Hint: you should look up useful numpy functions online for calculating the mean.

    Args:
        f: numpy array of shape (Hf, Wf).
        g: numpy array of shape (Hg, Wg).

    Returns:
        out: numpy array of shape (Hf, Wf).
    """

    Hi,Wi=f.shape
    z=g-g.mean()
    out=feature.match_template(f,z) #using builtin skimage function for correlation
    return out[0:Hi,0:Wi]

def normalized_cross_correlation(f, g):
    """ Normalized cross-correlation of f and g.

    Normalize the subimage of f and the template g at each step
    before computing the weighted sum of the two.

    Hint: you should look up useful numpy functions online for calculating 
          the mean and standard deviation.

    Args:
        f: numpy array of shape (Hf, Wf).
        g: numpy array of shape (Hg, Wg).

    Returns:
        out: numpy array of shape (Hf, Wf).
    """
    Hi, Wi = f.shape
    Hk, Wk = g.shape
    out = np.zeros((Hi, Wi))
    HiCen=(Hk//2)
    WiCen=(Wk//2)
    product=np.zeros((Hi+Hk-1,Wi+Wk-1))
    stdn=np.zeros((Hi+Hk-1,Wi+Wk-1))
    out2=np.zeros((Hi+Hk-1,Wi+Wk-1))
    ### YOUR CODE HERE
    for m in range(0,Hi+Hk-1):
        for n in range(0,Wi+Wk-1):
            for i in range(HiCen,Hk-HiCen):
                for j in range(WiCen,Wk-WiCen):
                    
                    
                        
                        product[m,n]=f[m,n]-f[i+HiCen,j+WiCen].mean()*(g[m-i,n-j]-g.mean())
                        stdn[m,n]=f[i+HiCen,j+WiCen].std()*g.std()
                        out2[m,n]+=product[m,n]//stdn[m,n]
    ### END YOUR CODE
    out=out2[0:Hi,0:Wi]
    return out
    
